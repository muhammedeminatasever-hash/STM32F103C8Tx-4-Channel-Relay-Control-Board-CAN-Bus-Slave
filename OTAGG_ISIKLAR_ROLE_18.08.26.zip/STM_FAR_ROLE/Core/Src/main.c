/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    : main.c
  * @brief   : STM32F103 4'lü Röle Kontrol Kartı (CAN-Bus Slave, ACTIVE LOW)
  *            TEK CAN ID (0x25) - Byte bazlı kontrol:
  *              data[0] = FAR
  *              data[1] = STOP
  *              data[2] = SAĞ SİNYAL
  *              data[3] = SOL SİNYAL
  *            Her byte: 0x00 = Kapat, 0x01 = Aç, 0xFF = Toggle
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"

/* === Tanımlar === */

/* ========== TEK CAN ID (EKLENDİ) ==========
 * Far/Stop/Sağ/Sol artık ayrı ID'ler değil, tek ID üzerinden
 * data byte'larıyla kontrol ediliyor.
 * ============================================ */
#define RELAY_CAN_ID      0x25U

#define RELAY_CMD_OFF     0x00U
#define RELAY_CMD_ON      0x01U
#define RELAY_CMD_TOGGLE  0xFFU

#define PIN_FAR   GPIO_PIN_0
#define PIN_STOP  GPIO_PIN_1
#define PIN_SAG   GPIO_PIN_2
#define PIN_SOL   GPIO_PIN_3
#define PIN_LED   GPIO_PIN_13

/* ========== BYTE INDEX <-> PIN EŞLEŞTİRME (GÜNCELLENDİ) ==========
 * Artık CAN ID'ye göre değil, gelen data paketindeki byte
 * pozisyonuna (index) göre pin seçiliyor:
 *   index 0 -> FAR
 *   index 1 -> STOP
 *   index 2 -> SAĞ SİNYAL
 *   index 3 -> SOL SİNYAL
 * ==================================================================== */
typedef struct {
    uint8_t  byteIndex;
    uint16_t pin;
} RelayMap_t;

static const RelayMap_t relay_map[] = {
    { 0U, PIN_FAR  },   /* data[0] */
    { 1U, PIN_STOP },   /* data[1] */
    { 2U, PIN_SAG  },   /* data[2] */
    { 3U, PIN_SOL  },   /* data[3] */
};

#define RELAY_COUNT  (sizeof(relay_map) / sizeof(relay_map[0]))

/* === Değişkenler === */
CAN_HandleTypeDef hcan;

/* === Özel Fonksiyonlar === */
static void Relay_Set(uint16_t pin, uint8_t active)
{
    HAL_GPIO_WritePin(GPIOA, pin, active ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

/* ========== TEK BYTE'A GÖRE RÖLE KOMUTU (EKLENDİ) ========== */
static void Relay_ApplyCmd(uint16_t pin, uint8_t cmd)
{
    if (cmd == RELAY_CMD_ON)
    {
        Relay_Set(pin, 1U);
    }
    else if (cmd == RELAY_CMD_OFF)
    {
        Relay_Set(pin, 0U);
    }
    else
    {
        /* 0xFF veya beklenmeyen değer -> toggle */
        HAL_GPIO_TogglePin(GPIOA, pin);
    }
}

/* ========== GELEN 8 BYTE'LIK PAKETİ İŞLE (GÜNCELLENDİ) ==========
 * Tek CAN mesajı içindeki 4 byte (Far/Stop/Sağ/Sol) sırayla
 * ilgili röleye uygulanır. DLC 4'ten küçükse eksik byte'lar
 * için komut uygulanmaz (güvenli taraf: dokunma).
 * =================================================================== */
static void Relay_Control(const uint8_t *data, uint8_t dlc)
{
    for (size_t i = 0; i < RELAY_COUNT; i++)
    {
        if (relay_map[i].byteIndex < dlc)
        {
            uint8_t cmd = data[relay_map[i].byteIndex];
            Relay_ApplyCmd(relay_map[i].pin, cmd);
        }
    }
}

static void MX_CAN_Init(void)
{
    hcan.Instance = CAN1;
    hcan.Init.Prescaler = 16;
    hcan.Init.Mode = CAN_MODE_NORMAL;
    hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
    hcan.Init.TimeSeg1 = CAN_BS1_2TQ;
    hcan.Init.TimeSeg2 = CAN_BS2_1TQ;
    hcan.Init.TimeTriggeredMode = DISABLE;
    hcan.Init.AutoBusOff = DISABLE;
    hcan.Init.AutoWakeUp = DISABLE;
    hcan.Init.AutoRetransmission = DISABLE;
    hcan.Init.ReceiveFifoLocked = DISABLE;
    hcan.Init.TransmitFifoPriority = DISABLE;
    HAL_CAN_Init(&hcan);
}

static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    HAL_GPIO_WritePin(GPIOC, PIN_LED, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, PIN_FAR | PIN_STOP | PIN_SAG | PIN_SOL, GPIO_PIN_SET);

    GPIO_InitTypeDef GPIO_InitStruct = {
        .Mode  = GPIO_MODE_OUTPUT_PP,
        .Pull  = GPIO_NOPULL,
        .Speed = GPIO_SPEED_FREQ_LOW
    };

    GPIO_InitStruct.Pin = PIN_LED;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = PIN_FAR | PIN_STOP | PIN_SAG | PIN_SOL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/* === Callback === */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    CAN_RxHeaderTypeDef rxHeader;
    uint8_t rxData[8];

    if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rxHeader, rxData) != HAL_OK)
        return;

    HAL_GPIO_TogglePin(GPIOC, PIN_LED);

    /* ========== TEK ID KONTROLÜ (GÜNCELLENDİ) ==========
     * Artık ID'ye göre HANGİ röle sürüleceği değil, sadece
     * mesajın bize ait olup olmadığı kontrol ediliyor.
     * Hangi rölenin sürüleceği data byte'larından belirlenir.
     * ====================================================== */
    if ((rxHeader.IDE == CAN_ID_STD) && (rxHeader.StdId == RELAY_CAN_ID))
    {
        Relay_Control(rxData, rxHeader.DLC);
    }
}

/* ========== SystemClock_Config (EKLENDİ) ==========
 * ÖNEMLİ: Bu fonksiyon önceki dosyada yalnızca yorum satırı
 * ("Mevcut SystemClock_Config() aynen kalabilir") olarak
 * bırakılmıştı ve gövdesi hiç paylaşılmamıştı; linker bu yüzden
 * "undefined reference" hatası verdi.
 *
 * Aşağıdaki implementasyon STM32F103C8 (Blue Pill) için CubeIDE'nin
 * tipik ürettiği HSE 8MHz + PLL x9 = 72MHz yapılandırmasıdır.
 *
 * >>> LÜTFEN KONTROL EDİN: Kartınızda gerçekten 8MHz harici kristal
 * (HSE) var mı? Eğer kristalsiz / dahili osilatör (HSI) kullanan bir
 * kart ise ya da orijinal .ioc dosyanızda farklı bir saat ağacı
 * ayarlıysa, bu fonksiyonu CubeMX/.ioc dosyanızdaki gerçek ayarlarla
 * değiştirmeniz gerekir. Yanlış saat kaynağı CAN baud rate'ini
 * doğrudan etkiler.
 * ==================================================================== */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
    RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL4;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                 | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
    {
        Error_Handler();
    }
}

/* ========== Error_Handler (EKLENDİ) ==========
 * Bu da aynı şekilde önceki dosyada gövdesiz bırakılmıştı.
 * Master karttaki ile aynı standart CubeIDE implementasyonu.
 * ================================================================ */
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
    }
}

/* === Ana Program === */
int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_CAN_Init();

    /* ========== CAN FİLTRE (TEK ID'YE GÖRE GÜNCELLENDİ) ==========
     * Artık 4 ID'lik bir liste değil, TEK ID (0x25) için
     * ID-Mask filtresi kullanılıyor. Mask = 0x7FF (tüm bitler
     * eşleşmeli) ile sadece RELAY_CAN_ID kabul edilir.
     * StdId 11-bit olduğundan filtre register'ında sol tarafa
     * (<<5) hizalanır; STM32 HAL 32-bit filtre bölme kuralı
     * gereği FilterIdHigh/Low ve FilterMaskIdHigh/Low aynı
     * ID ve maskeyi 16-bit'lik iki parçaya böler.
     * =================================================================== */
    CAN_FilterTypeDef sFilterConfig = {
        .FilterBank           = 0,
        .FilterMode           = CAN_FILTERMODE_IDMASK,
        .FilterScale          = CAN_FILTERSCALE_16BIT,
        .FilterFIFOAssignment = CAN_FILTER_FIFO0,
        .FilterActivation     = CAN_FILTER_ENABLE,
        .FilterIdHigh         = (uint16_t)(RELAY_CAN_ID << 5),
        .FilterIdLow          = (uint16_t)(RELAY_CAN_ID << 5),
        .FilterMaskIdHigh     = (uint16_t)(0x7FFU << 5),
        .FilterMaskIdLow      = (uint16_t)(0x7FFU << 5),
    };
    HAL_CAN_ConfigFilter(&hcan, &sFilterConfig);
    HAL_CAN_Start(&hcan);
    HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING);

    /* Tüm röleleri pasif yap (ACTIVE LOW → HIGH) */
    for (size_t i = 0; i < RELAY_COUNT; i++)
        Relay_Set(relay_map[i].pin, 0);

    while (1) {
        HAL_SuspendTick();
        HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);
        HAL_ResumeTick();
    }
}
